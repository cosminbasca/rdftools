__author__ = 'basca'

version = (0, 7, 3)
str_version = '.'.join(['%s' % v for v in version])