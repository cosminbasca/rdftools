__author__ = 'basca'

version = (0, 8, 7)
str_version = '.'.join(['%s' % v for v in version])