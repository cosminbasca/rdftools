__author__ = 'basca'

version = (0, 8, 6)
str_version = '.'.join(['%s' % v for v in version])