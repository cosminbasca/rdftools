__author__ = 'basca'

version = (0, 8, 4)
str_version = '.'.join(['%s' % v for v in version])