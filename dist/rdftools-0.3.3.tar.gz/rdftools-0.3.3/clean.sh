#!/bin/sh
clear
rm ./rdftools/*.c
rm ./rdftools/*.cpp
rm ./rdftools/*.h
rm ./rdftools/*.so
