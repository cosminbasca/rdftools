#!/bin/sh
clear
python setup_du.py build_ext --inplace
