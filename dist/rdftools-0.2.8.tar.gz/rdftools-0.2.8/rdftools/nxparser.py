import os

__author__ = 'basca'

BUNDLED_NXPARSER_JAR = os.path.join(os.path.split(__file__)[0],'deps','nxparser','nxparser-1.2.3.jar')