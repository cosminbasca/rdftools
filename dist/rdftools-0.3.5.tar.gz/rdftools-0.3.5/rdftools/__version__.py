__author__ = 'basca'

version = (0, 3, 5)
str_version = '.'.join(['%s' % v for v in version])